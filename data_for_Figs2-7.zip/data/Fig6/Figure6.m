clc;
clear;

wv = [ 370   470   520   590   660   880];
All = [80.4220   50.0399   41.4756   36.1832   32.0124   19.5382];
BC = [46.4692   36.5822   33.0646   29.1417   26.0509   19.5382];

Figure1 = figure('Position',[50 50 600 500]);

subplot1 = subplot('position',[0.15 0.15 0.75 0.72],'YMinorTick','on','XMinorTick','on',...
                  'XScale','linear','YScale','linear',...
                  'XTick',[300:100:900],'XTickLabel',{'','400','500','600','700','800','900'},...
                  'YTick',[10:20:90],'YTickLabel',{'10','30','50','70','90'},...
                  'FontSize',20);
box('on');
hold('all');
hold on;

plot(wv,BC,'Color',[0 0 0],'linewidth',2,'DisplayName','Fit for BC');
plot(wv,All,'Color',[0.627 0.321 0.176],'linewidth',2,'DisplayName','Fit for observation');
legend1 = legend('show');
set(legend1,'FontSize',24,'EdgeColor',[1 1 1],'position',[0.55 0.60 0.14 0.18]);

fill([wv,fliplr(wv)],[All,fliplr(BC)],[0.627 0.321 0.176],'edgealpha',0,'facealpha',0.3);
fill([wv,fliplr(wv)],[BC,0*ones(1,length(BC))],[0 0 0],'edgealpha',0,'facealpha',0.3);

text(400,20,'BC','Fontsize',20);
text(400,52,'BrC','Fontsize',20);


xlim([350 900]);
ylim([10 90]);
xlabel('Wavelength (nm)','FontSize',20);
ylabel('Abs (mm^{-1})','FontSize',20);
